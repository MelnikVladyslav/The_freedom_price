﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Name objects", menuName = "Path for create objects")]
public class Shablon : ScriptableObject {

    //вводимо різні змінніб або масив даних через List<тип даних>
}
